# GrowLab – Die grüne Lizenz (MVP 0.1)

Ein eigenständiger, deutschsprachiger, mobiloptimierter Browser-Prototyp ohne Lovable, Build-Prozess oder externe Abhängigkeiten.

## Spielen

`index.html` in einem Browser öffnen. Für das iPhone empfiehlt sich ein statischer Webhost (z. B. GitHub Pages); die Datei kann dort direkt veröffentlicht werden.

## Bereits spielbar

- Growroom mit Pflanzenplätzen, Pflanzenstatus, Pflege, Ernte und Ausbau
- Rundenbasierte Spieltage mit Energie und Schlafen
- Vier reale Sortennamen mit vereinfachten, fiktiven Spielwerten und traditionellen Kategorien
- Saatgut kaufen, Ernte lagern und verkaufen, einfache Finanzübersicht
- Genetikprojekte über drei Spieltage und Selektion von 1–3 Kandidaten
- Genetikarchiv für eigene F1-Hybride
- Automatischer lokaler Spielstand sowie JSON-Export
- Mobile Navigation mit fünf Bereichen

## Bewusst noch nicht umgesetzt

- Separat steuerbare Grow-Zelte und Klimaprofile
- Mitarbeiter, Produktion und Hallenbau
- Historische Rezeptdatenbank, Händler-NPCs, Forschungsaufträge
- Echte Pixel-Art-Sprites, Story-Quests und Sound
- Vollständige Generationenfolge und stabile Genetiklinien
- Cloud-Synchronisation und App-Verpackung

## Technische Hinweise

- Alle Werte, Wachstumszeiten und genetischen Merkmale sind abstrakte Spielparameter, keine realen Anbauempfehlungen.
- Speicherort: `localStorage`, Schlüssel `growlab_v1_save`. Private Browsing, Browserdaten-Löschung oder ein Gerätewechsel können den Spielstand entfernen. JSON-Export als Sicherung verwenden.
- Keine Server-Komponente, keine Tracking-Dienste, keine externen Abhängigkeiten.
- Für spätere Erweiterungen kann die App in modulare TypeScript-/React-Komponenten überführt werden.
